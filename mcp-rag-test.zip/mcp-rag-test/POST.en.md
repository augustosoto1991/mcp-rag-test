# From Dead Documentation to an Agent That Acts: RAG + MCP + Copilot in Your Dev Workflow

> How to transform your team's technical documentation into an intelligent assistant that answers questions, executes real actions, and lives inside your editor. No vendor lock-in. No expensive infrastructure. With fully local models.

---

## The Problem Nobody Admits But Everyone Suffers

There's a conversation that happens in almost every engineering team, with different variations but the same pattern:

> *"Where do TypeScript types go in this project?"*
>
> *"What's the endpoint to create an order? Is it in Swagger or Confluence?"*
>
> *"When should I create a new service vs. extend an existing one?"*

These questions seem simple. But to answer them, the typical developer has to:

1. Leave the editor
2. Open a browser
3. Search in Confluence, the wiki, Swagger, or Slack
4. Find nothing clear
5. Ask the senior developer who "knows everything"
6. Return to the editor, breaking their concentration

**This cycle repeats dozens of times per day.** And it has a real cost:

- Onboarding new developers takes weeks instead of days
- Critical dependency on specific people ("the one who knows how X works")
- Documentation that gets written but never used because it's hard to find
- Constant context switching that destroys productivity

The technical knowledge exists. The problem is that it's distributed, hard to find, and completely disconnected from the environment where work happens: the editor.

---

## The Proposal: Four Stages of Evolution

The solution isn't a new tool. It's a gradual evolution of something teams already have: **documentation**.

```
Stage 1 ─── Static Markdown documentation
                ↓
Stage 2 ─── Documentation + RAG
             (knowledge answers questions in natural language)
                ↓
Stage 3 ─── RAG + MCP Server
             (the assistant can also execute real actions)
                ↓
Stage 4 ─── Everything integrated in Copilot / Claude / Cline
             (without leaving the editor, without context switching)
```

Each stage adds incremental value. A team can adopt just the first two stages and already get significant benefits. Stages three and four are what turns the system into something truly powerful.

---

## The Fundamental Principle

Before diving into the architecture, there's a principle that guides all design decisions:

> **RAG answers questions. MCP executes actions.**

When a developer asks *"what statuses can an order return?"*, that's a question. The system should search the documentation and answer.

When a developer says *"create an order and process the payment"*, that's an action. The system should execute real API calls.

This clear separation between knowledge and execution is what makes the system robust, predictable, and easy to extend.

---

## System Architecture

```
Developer
    │
    ▼
MCP Client
(Copilot / Claude Desktop / Cline / any MCP client)
    │
    │  Model Context Protocol — Streamable HTTP
    ▼
MCP Server  :3001
    │                         │
    ▼                         ▼
RAG Engine               API (Mock or real)
    │                         │
    ▼                         ▼
Knowledge base            Endpoints
(Markdown → embeddings    (/orders, /payments,
 → semantic search)        any service)
```

There are four main components. Each has a unique and well-defined responsibility.

---

### Component 1: The Knowledge Base

The starting point is the documentation the team should already have: Markdown files describing the API, development standards, architectural decisions, and team guidelines.

What changes isn't the format but the **intent**: documentation is written thinking it will be read by both humans and AI systems. This means:

- Clear, hierarchical headings
- Short, focused sections
- Lists instead of long paragraphs
- Code blocks with concrete examples

This investment in documentation quality pays double dividends: it improves the human experience of reading the docs *and* improves the accuracy of RAG responses.

---

### Component 2: The RAG Engine

RAG stands for *Retrieval Augmented Generation*. It's a technique that allows language models to answer questions using specific information, rather than relying solely on what they learned during training.

The pipeline works like this:

```
1. Document Loading
   Markdown files are read recursively from the filesystem

2. Chunking
   Each document is split into ~1000 character fragments
   with 200-character overlap to preserve context between chunks

3. Embedding
   Each fragment is converted into a numerical vector (768 dimensions)
   using the nomic-embed-text model running locally in Ollama

4. Storage
   (fragment, vector) pairs are stored in memory
   and persisted to a JSON file to avoid re-processing on each search

5. Semantic Search
   When a query arrives:
   → the query is embedded with the same model
   → cosine similarity is calculated against all stored vectors
   → the top-k most relevant fragments are returned
```

The key is step 5: **cosine similarity** measures how "close" two vectors are in mathematical space. Two texts talking about the same topic will have similar vectors, even if they use different words. This is what makes semantic search fundamentally superior to keyword search.

---

### Component 3: The MCP Server

MCP (Model Context Protocol) is an open protocol created by Anthropic that standardizes how language models interact with external tools. Think of it as an API, but designed specifically for AI models to consume.

The MCP Server exposes **tools**: named functions with descriptions and input/output schemas that the model can invoke when needed.

In this project, the tools are:

| Tool | Description | Implementation |
|---|---|---|
| `health_check` | Verifies the status of all components | Checks API, Ollama, and RAG index |
| `search_docs` | Semantic search in documentation | Calls the RAG engine |
| `create_order` | Creates a new order | `POST /orders` |
| `get_order` | Queries the status of an order | `GET /orders/:id` |
| `create_payment` | Processes a payment for an order | `POST /payments` |

Communication uses **Streamable HTTP** (the current MCP protocol standard), which means the server is simply an HTTP endpoint. Any client that speaks the protocol can connect.

---

### Component 4: The Client (Copilot, Claude, Cline)

This is the most important component from the developer's perspective because it's the only one they see.

The client receives the developer's natural language instruction, decides which tools to invoke (can be one or several in sequence), executes calls to the MCP Server, and synthesizes the results into a coherent response.

The notable thing is that **the MCP Server knows nothing about the client**. It's completely agnostic. The same server that GitHub Copilot uses can be used by Claude Desktop, Cline, or any other tool that adopts the protocol. There's no vendor lock-in in either direction.

---

## Why Ollama: The Decision That Makes It Accessible

One of the most important decisions was using Ollama instead of an external embedding service like OpenAI.

| Criterion | Ollama (local) | OpenAI / Azure |
|---|---|---|
| Cost | Zero | Per token, accumulates quickly |
| API Key | Not required | Required, managed |
| Privacy | Data never leaves the team | Cloud processing |
| Reproducibility | Any dev can run it identically | Depends on API versions |
| Latency | Depends on local hardware | Depends on network |
| Offline | Works without internet | Requires connectivity |

For a team working with proprietary code or sensitive information, this decision is critical. **Internal documents, standards, and architecture never leave the local environment.**

For a team that needs to scale or prefers convenience, the project's architecture makes switching easy: just swap `OllamaEmbeddings` for `OpenAIEmbeddings` in a single file.

---

## Index Persistence: A Detail That Changes Everything

Without persistence, every search would require reprocessing all documents: loading them, chunking them, and generating embeddings for each fragment. In a system with dozens or hundreds of documents, this would take minutes for every query.

The implemented solution is simple but effective: after building the index for the first time, it's serialized to an `index.json` file. Subsequent searches load directly from this cache, without touching Ollama.

```bash
# Only needed once, or when documentation changes
cd rag && npm run build-index

# All subsequent searches use the cache — milliseconds instead of minutes
npm run search -- "your question"
```

---

## The health_check Tool: Diagnostics From the Editor

An addition that seems minor but proves very useful in practice: a system diagnostic tool.

When something isn't working, the developer can ask directly in the chat:

> *"Are all systems working?"*

And receive:

```
✅ API Mock — http://localhost:3000
✅ RAG Index — 12 chunks loaded
✅ Ollama — http://localhost:11434
✅ Ollama model — nomic-embed-text

All systems operational.
```

Or if there's a problem:

```
✅ API Mock — http://localhost:3000
❌ RAG Index — index.json not found — run: cd rag && npm run build-index
✅ Ollama — http://localhost:11434
✅ Ollama model — nomic-embed-text

One or more components need attention.
```

Without leaving the editor, without opening additional terminals, with resolution instructions included.

---

## Not Exclusive to Copilot: The Power of the Open Standard

This is one of the most important and least obvious aspects of the design.

The MCP Server we built can connect to any client that implements the MCP protocol:

| Client | Type |
|---|---|
| GitHub Copilot | VS Code extension |
| Claude Desktop | Native desktop application |
| Cline | VS Code extension (autonomous agent) |
| Roo Code | VS Code extension (Cline fork) |
| Cursor | VS Code-based editor |
| Windsurf | Codeium's editor |
| Continue.dev | Open source extension for VS Code and JetBrains |

The configuration for each client is practically identical: a URL pointing to the `/mcp` endpoint. The team can choose the tool they're most comfortable with without changing anything in the server.

---

## Concrete Benefits by Role

### For the New Developer

Onboarding is the most immediate use case. Instead of:

- Reading outdated READMEs
- Asking colleagues who are in the middle of another task
- Exploring the code to infer conventions

The developer can ask directly:

> *"How do I add a new endpoint to this project?"*
> *"Where should I put the TypeScript types?"*
> *"What's the standard error handling pattern here?"*

And receive answers based on the project's real documentation, immediately, without interrupting anyone.

---

### For the Senior Developer

The senior developer is typically the knowledge bottleneck. Answering the same questions repeatedly has a real productivity cost.

With this system, the knowledge that senior developer has in their head is externalized to the RAG knowledge base. Frequently asked questions are answered automatically. The senior's time is freed for higher-value work.

---

### For the Tech Lead

Development standards are useless if nobody finds them when they need them. With the RAG indexing the standards documentation, the team can consult conventions in context, at the moment they need them, without breaking their workflow.

> *"Should I use async/await or promises here?"*
> *"What's the naming convention for service files?"*

---

### For the Team as a Whole

- **Less dependency on specific experts**: knowledge is accessible to everyone
- **Faster onboarding**: days instead of weeks for a new developer to become productive
- **Documentation that gets used**: when documentation generates real value, there's more incentive to keep it updated
- **Reduction in interruptions**: low-level questions are answered without interrupting others

---

### For the Organization

- **Retention of institutional knowledge**: when an experienced developer leaves, their knowledge remains in the system
- **Scalability**: adding more documentation expands the assistant's capabilities without changing the infrastructure
- **Auditability**: all queries and actions pass through the MCP Server, enabling logging and traceability

---

## How to Take This to a Real System

This project is an educational PoC. Taking the approach to a production system requires some adaptations:

### Replace the knowledge source

Instead of local Markdown files:

```
Confluence / Notion    →  loader consuming the platform's API
Swagger / OpenAPI      →  loader processing YAML/JSON specifications
Git repositories       →  loader indexing READMEs, ADRs, inline docs
Internal databases     →  loader querying and structuring knowledge
```

The RAG pipeline (chunking → embedding → similarity) stays the same. Only the loader changes.

---

### Replace Ollama with cloud embeddings

If the team prefers not to manage local models or needs higher quality:

```typescript
// Change in a single file: rag/src/vector-store.ts
// Before:
import { OllamaEmbeddings } from "@langchain/ollama";
const embeddings = new OllamaEmbeddings({ model: "nomic-embed-text" });

// After:
import { OpenAIEmbeddings } from "@langchain/openai";
const embeddings = new OpenAIEmbeddings({ model: "text-embedding-3-small" });
```

---

### Add authentication to the MCP Server

For environments where the server is network-accessible:

```typescript
// Authentication middleware in server.ts
app.use('/mcp', (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token !== process.env.MCP_AUTH_TOKEN) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
});
```

---

### Robust vector store persistence

For large documentation volumes, replace the flat JSON with a vector database:

```
LanceDB    → embedded, no server, ideal for small teams
pgvector   → PostgreSQL extension, integrates with existing infrastructure
Pinecone   → SaaS, automatic scalability
Weaviate   → open source, self-hosted
```

---

## The Recommended Adoption Path

It's not necessary to implement everything from day one. Value can be captured incrementally:

**Weeks 1-2: Documentation + RAG**
- Audit and structure existing documentation
- Set up Ollama and build the first index
- Validate that searches return relevant results

**Weeks 3-4: Basic MCP Server**
- Expose `search_docs` and `health_check`
- Connect with the client the team prefers
- Measure usage and gather feedback

**Month 2: Gradual expansion**
- Add tools for the most frequent actions
- Expand the knowledge base with more documentation
- Iterate on chunk quality and embedding performance

**Month 3+: Deep integration**
- Connect to real systems
- Add logging and usage metrics
- Explore more complex use cases (multi-step workflows)

---

## Conclusion

The question every tech lead should ask isn't *"should we adopt AI in our development workflow?"* but *"how much valuable knowledge is trapped in places where nobody finds it?"*

RAG, MCP, and AI clients like Copilot or Claude aren't magic solutions. They're tools that amplify the value of something the team should already have: **quality technical documentation**.

The system built in this PoC demonstrates that:

1. The barrier to entry is low: Node.js, TypeScript, and Ollama are enough for an MVP
2. There's no lock-in: the same server works with Copilot, Claude, Cline, and any future MCP client
3. Privacy is achievable: local models process internal knowledge without sending it to third parties
4. Evolution is gradual: each stage delivers independent value

The developer of the future won't search in Confluence. They'll ask in their editor, get an answer based on the team's real knowledge, and execute the necessary action — all without changing context.

That future can be built today, with open source tools, over a weekend.

---

## References and Resources

- [Model Context Protocol](https://modelcontextprotocol.io) — Official protocol specification
- [Ollama](https://ollama.com) — Local language models
- [LangChain TypeScript](https://js.langchain.com) — RAG orchestration framework
- [MCP TypeScript SDK](https://github.com/modelcontextprotocol/typescript-sdk) — Official SDK for building MCP servers
- [Project repository](https://github.com) — Complete repository with all phases implemented

---

*This article accompanies the `mcp-rag-test` repository, an educational PoC with full implementation of all described phases.*
