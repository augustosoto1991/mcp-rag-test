# AI Developer Experience PoC — Arquitectura Tecnica

> Documentacion tecnica y funcional completa del proyecto `mcp-rag-test`.
> Cubre todas las fases de implementacion, decisiones de diseno, estructura de codigo y flujos de integracion.

---

## Indice

1. [Vision General](#vision-general)
2. [Arquitectura del Sistema](#arquitectura-del-sistema)
3. [Fases de Implementacion](#fases-de-implementacion)
4. [Fase 1 — API Mock](#fase-1--api-mock)
5. [Fase 2 — Documentacion](#fase-2--documentacion)
6. [Fase 3 — RAG Local](#fase-3--rag-local)
7. [Fase 4 — Persistencia del Indice](#fase-4--persistencia-del-indice)
8. [Fase 5 — MCP Server](#fase-5--mcp-server)
9. [Fase 6 — GitHub Copilot](#fase-6--github-copilot)
10. [Estructura del Repositorio](#estructura-del-repositorio)
11. [Variables de Entorno](#variables-de-entorno)
12. [Guia de Uso](#guia-de-uso)
13. [Decisiones Tecnicas](#decisiones-tecnicas)

---

## Vision General

Este proyecto demuestra como una organizacion puede evolucionar desde documentacion estatica hacia asistentes inteligentes capaces de responder preguntas y ejecutar acciones reales, todo integrado en el flujo de trabajo del desarrollador dentro de VS Code.

```
Problema:
  Conocimiento distribuido → Documentacion + Wikis + Swagger + Conocimiento tribal

Solucion:
  RAG  →  responde preguntas semanticamente sobre documentacion
  MCP  →  ejecuta acciones reales sobre la API
  Copilot  →  interfaz conversacional dentro de VS Code
```

---

## Arquitectura del Sistema

```
Developer
    │
    ▼
GitHub Copilot Chat (VS Code)
    │
    │  MCP Protocol (Streamable HTTP)
    ▼
MCP Server  :3001
   │              │
   │              │
   ▼              ▼
RAG Engine    API Mock  :3000
   │              │
   ▼              ▼
index.json    Endpoints
(embeddings   /orders
 cacheados)   /payments
```

### Principio fundamental

| Capa | Responsabilidad |
|---|---|
| **RAG** | Responde preguntas usando busqueda semantica sobre documentacion |
| **MCP** | Ejecuta acciones reales: crear ordenes, procesar pagos, consultar estado |
| **Copilot** | Interfaz conversacional del desarrollador, orquesta RAG y MCP |

---

## Fases de Implementacion

| Fase | Nombre | Estado | Descripcion |
|---|---|---|---|
| 1 | API Mock | ✅ Completa | Servidor Express con endpoints de ordenes y pagos |
| 2 | Documentacion | ✅ Completa | Base de conocimiento Markdown indexada por el RAG |
| 3 | RAG Local | ✅ Completa | Motor de busqueda semantica con Ollama + LangChain |
| 4 | Persistencia del Indice | ✅ Completa | Cache del indice en JSON para evitar re-embedding |
| 5 | MCP Server | ✅ Completa | Servidor MCP con Streamable HTTP, 4 tools |
| 6 | GitHub Copilot | ✅ Completa | Configuracion VS Code + pruebas end-to-end |

---

## Fase 1 — API Mock

### Objetivo

Proveer un servicio HTTP minimalista que simule un dominio de ordenes y pagos sin infraestructura adicional.

### Caracteristicas

- Sin base de datos
- Sin autenticacion
- Sin persistencia
- Respuestas generadas aleatoriamente
- Dominio simple: ordenes y pagos

### Estructura

```
api/
├── package.json
├── tsconfig.json
└── src/
    ├── server.ts           # Express app, puerto 3000
    ├── routes/
    │   ├── orders.ts       # POST /orders, GET /orders/:id
    │   └── payments.ts     # POST /payments
    ├── services/
    │   └── random.ts       # randomId(), pickRandom()
    └── types/
        ├── order.ts        # Interface Order
        └── payment.ts      # Interface Payment
```

### Endpoints

| Metodo | Ruta | Descripcion |
|---|---|---|
| `GET` | `/health` | Health check |
| `POST` | `/orders` | Crear nueva orden |
| `GET` | `/orders/:id` | Consultar estado de orden |
| `POST` | `/payments` | Crear pago para una orden |

### Contratos

#### POST /orders

Request: sin body

Response:
```json
{
  "orderId": "ord_abc123",
  "status": "created",
  "createdAt": "2026-01-01T00:00:00Z"
}
```

#### GET /orders/:id

Response:
```json
{
  "orderId": "ord_abc123",
  "status": "processing",
  "updatedAt": "2026-01-01T00:00:00Z"
}
```

Estados posibles: `created` | `processing` | `completed`

#### POST /payments

Request:
```json
{ "orderId": "ord_abc123" }
```

Response:
```json
{
  "paymentId": "pay_xyz123",
  "orderId": "ord_abc123",
  "status": "approved",
  "createdAt": "2026-01-01T00:00:00Z"
}
```

Estados posibles: `approved` | `declined` | `pending`

### Scripts

```bash
cd api
npm run dev    # tsx watch src/server.ts (live reload)
npm run build  # tsc → dist/
npm start      # node dist/server.js
```

### Dependencias clave

| Paquete | Version | Rol |
|---|---|---|
| `express` | ^5 | Framework HTTP |
| `cors` | latest | Middleware CORS |
| `typescript` | ^5 | Lenguaje |
| `tsx` | latest | Ejecucion TS directa |

---

## Fase 2 — Documentacion

### Objetivo

Construir una base de conocimiento estructurada en Markdown que sea consumida por el RAG y comprensible tanto por humanos como por modelos de lenguaje.

### Estructura

```
api/docs/
├── api/
│   ├── overview.md         # Descripcion general de la API
│   ├── orders.md           # Documentacion del recurso Orders
│   └── payments.md         # Documentacion del recurso Payments
├── architecture/
│   └── system-overview.md  # Componentes, responsabilidades, relaciones
├── development/
│   ├── coding-standards.md # Convenciones TypeScript del proyecto
│   └── adding-endpoints.md # Guia paso a paso para extender la API
└── ai/
    ├── rag-overview.md      # Que es RAG y como funciona en este proyecto
    ├── rag-architecture.md  # Pipeline tecnico del RAG
    ├── rag-installation.md  # Instrucciones de instalacion
    ├── rag-use-cases.md     # Casos de uso del RAG
    ├── rag-limitations.md   # Limitaciones conocidas
    └── mcp-guidelines.md   # Cuando usar MCP vs RAG
```

### Principios de escritura para IA

- Encabezados claros y jerarquicos (`#`, `##`, `###`)
- Fragmentos de codigo con bloques \`\`\` tipados
- Listas concisas en lugar de parrafos largos
- Separadores `---` entre secciones
- Lenguaje directo sin ambiguedad

### Ubicacion relativa al RAG

El modulo `rag/` lee los documentos desde `../api/docs` (relativo a su directorio de ejecucion). Esta co-localizacion es intencional: los docs viven junto a la API que describen.

---

## Fase 3 — RAG Local

### Objetivo

Implementar un motor de busqueda semantica capaz de responder preguntas en lenguaje natural sobre la documentacion del proyecto.

### Estructura

```
rag/
├── package.json
├── tsconfig.json
├── .env                    # OLLAMA_BASE_URL=http://localhost:11434
└── src/
    ├── index.ts            # Demo: construye store y ejecuta query hardcodeada
    ├── search.ts           # CLI: lee query de process.argv
    ├── search-docs.ts      # API publica: searchDocs(query, limit)
    ├── vector-store.ts     # Core: SimpleMemoryVectorStore + buildVectorStore()
    ├── load-docs.ts        # Carga archivos .md recursivamente desde api/docs/
    ├── persist.ts          # saveIndex() / loadIndex() — persistencia JSON
    └── build-index.ts      # Entrypoint para forzar reconstruccion del indice
```

### Pipeline tecnico

```
api/docs/ (.md files)
        ↓
load-docs.ts
  Lee todos los .md recursivamente
  Crea Document { pageContent, metadata.source }
        ↓
RecursiveCharacterTextSplitter
  chunkSize: 1000
  chunkOverlap: 200
        ↓
OllamaEmbeddings
  model: nomic-embed-text
  baseUrl: process.env.OLLAMA_BASE_URL
        ↓
SimpleMemoryVectorStore
  Array<{ content: Document, embedding: number[] }>
  Cosine similarity manual
        ↓
similaritySearch(query, k)
  Embeds query → cosine similarity → top-k results
        ↓
[{ source: string, content: string }]
```

### SimpleMemoryVectorStore

Implementacion propia de `VectorStore` (LangChain abstract class).

| Metodo | Descripcion |
|---|---|
| `addDocuments(docs)` | Genera embedding por cada doc via Ollama y lo almacena |
| `addVectors(vectors, docs)` | Almacena vectores pre-generados directamente |
| `similaritySearchVectorWithScore(query, k)` | Cosine similarity contra todos los vectores almacenados |
| `cosineSimilarity(a, b)` | Dot product / (magnitudeA * magnitudeB) |

### Por que Ollama

| Criterio | Decision |
|---|---|
| Costo | Cero — modelo local |
| API Keys | No requiere |
| Privacidad | Los datos no salen del equipo |
| Reproducibilidad | Cualquier desarrollador puede correrlo |
| Modelo usado | `nomic-embed-text` (768 dimensiones) |

### Scripts

```bash
cd rag
npm run build-index   # Construye y persiste el indice (requiere Ollama)
npm run search -- "tu pregunta"  # Busca usando el indice cacheado
npm run index         # Demo con query hardcodeada
```

---

## Fase 4 — Persistencia del Indice

### Objetivo

Evitar re-generar embeddings en cada busqueda. El indice se construye una sola vez y se serializa a disco.

### Implementacion

**Archivo:** `rag/src/persist.ts`

| Funcion | Descripcion |
|---|---|
| `saveIndex(documents)` | Serializa `Array<{content, embedding}>` a `index.json` en la raiz del repo |
| `loadIndex()` | Deserializa `index.json` y reconstruye los `Document` objects. Retorna `null` si no existe |

**Archivo de cache:** `index.json` (raiz del repositorio)

Estructura del JSON:
```json
[
  {
    "content": {
      "pageContent": "# Orders API\n...",
      "metadata": { "source": "api/orders.md" }
    },
    "embedding": [0.023, -0.041, ...]
  }
]
```

### Flujo con cache

```
npm run search -- "query"
        ↓
buildVectorStore(forceRebuild = false)
        ↓
loadIndex()
  ├── index.json existe → carga cache → retorna store (sin llamar a Ollama)
  └── no existe → construye desde cero → saveIndex() → retorna store
```

### Flujo de reconstruccion

```
npm run build-index
        ↓
buildVectorStore(forceRebuild = true)
        ↓
Ignora cache → construye desde cero → saveIndex()
```

### Cuando re-indexar

- Al agregar o modificar archivos en `api/docs/`
- Al cambiar el modelo de embeddings
- Al cambiar `chunkSize` o `chunkOverlap`

---

## Fase 5 — MCP Server

### Objetivo

Exponer las capacidades del sistema (RAG + API) como herramientas MCP que cualquier cliente compatible (GitHub Copilot, Claude Desktop, etc.) pueda invocar.

### Protocolo

**MCP (Model Context Protocol):** protocolo abierto de Anthropic que estandariza como los modelos de lenguaje interactuan con herramientas externas.

**Transporte elegido:** Streamable HTTP (MCP spec 2025-03-26)
- Endpoint unico: `POST /mcp` y `GET /mcp`
- Sin necesidad de mantener conexiones SSE persistentes
- Compatible con GitHub Copilot en VS Code

### Estructura

```
mcp-server/
├── package.json            # @modelcontextprotocol/sdk, express, dotenv, tsx
├── tsconfig.json
├── .env                    # API_BASE_URL, PORT
└── src/
    ├── server.ts           # McpServer + StreamableHTTP + Express
    ├── api-client.ts       # Fetch helper tipado para la API Mock
    └── tools/
        ├── search-docs.ts  # Tool: search_docs
        ├── orders.ts       # Tools: create_order, get_order
        └── payments.ts     # Tool: create_payment
```

### Tools registrados

| Tool | Input Schema | Output | Fuente |
|---|---|---|---|
| `search_docs` | `{ query: string, limit?: number }` | `[{ source, content }]` | `rag/src/search-docs.ts` |
| `create_order` | _(sin input)_ | `{ orderId, status, createdAt }` | `POST /orders` |
| `get_order` | `{ orderId: string }` | `{ orderId, status, updatedAt }` | `GET /orders/:id` |
| `create_payment` | `{ orderId: string }` | `{ paymentId, orderId, status, createdAt }` | `POST /payments` |

### Variables de entorno

```env
API_BASE_URL=http://localhost:3000
PORT=3001
```

### Dependencias clave

| Paquete | Rol |
|---|---|
| `@modelcontextprotocol/sdk` | SDK oficial MCP — McpServer, tools, Streamable HTTP transport |
| `express` | Servidor HTTP que aloja el endpoint `/mcp` |
| `zod` | Validacion de schemas de inputs de los tools |
| `dotenv` | Variables de entorno |
| `tsx` | Ejecucion TypeScript directa |

### Scripts

```bash
cd mcp-server
npm run dev    # tsx watch src/server.ts — servidor en :3001
npm start      # tsx src/server.ts
```

### Flujo de una llamada a tool

```
Copilot invoca tool "search_docs" con { query: "..." }
        ↓
MCP Server recibe POST /mcp
        ↓
SDK deserializa y valida input con Zod
        ↓
Handler: searchDocs(query, limit)
        ↓
buildVectorStore() → loadIndex() desde cache
        ↓
similaritySearch(query, k)
        ↓
Retorna [{ source, content }] como tool result
        ↓
SDK serializa respuesta → HTTP response
        ↓
Copilot usa el resultado para generar respuesta al desarrollador
```

---

## Fase 6 — GitHub Copilot

### Objetivo

Conectar GitHub Copilot en VS Code al MCP Server para que el desarrollador pueda hacer preguntas y ejecutar acciones sin salir del editor.

### Configuracion

**Archivo:** `.vscode/mcp.json`

```json
{
  "servers": {
    "mcp-rag-test": {
      "type": "http",
      "url": "http://localhost:3001/mcp"
    }
  }
}
```

### Requisitos

- VS Code con GitHub Copilot instalado y activo
- Copilot Chat habilitado
- MCP Server corriendo en `:3001`
- API Mock corriendo en `:3000`

### Activar modo agente en Copilot Chat

1. Abrir Copilot Chat (`Ctrl+Alt+I` / `Cmd+Alt+I`)
2. Seleccionar modo **Agent** en el selector de modo
3. Los tools del MCP Server apareceran disponibles automaticamente

### Prompts de prueba

| Prompt | Tool invocado | Tipo |
|---|---|---|
| `"¿Que estados puede devolver una orden?"` | `search_docs` | RAG |
| `"¿Cuando debo crear un MCP tool vs usar RAG?"` | `search_docs` | RAG |
| `"¿Como agrego un nuevo endpoint?"` | `search_docs` | RAG |
| `"Crea una nueva orden"` | `create_order` | Accion |
| `"Consulta el estado de la orden ord_abc123"` | `get_order` | Accion |
| `"Procesa el pago de la orden ord_abc123"` | `create_payment` | Accion |
| `"Crea una orden y luego procesa su pago"` | `create_order` + `create_payment` | Multi-accion |

---

## Estructura del Repositorio

```
mcp-rag-test/
│
├── ARCHITECTURE.md         # Este documento
├── readme.md               # Documentacion funcional del proyecto
├── index.json              # Cache del indice RAG (generado, no editar)
│
├── api/                    # Fase 1 — Mock REST API
│   ├── package.json
│   ├── tsconfig.json
│   ├── src/
│   │   ├── server.ts
│   │   ├── routes/
│   │   │   ├── orders.ts
│   │   │   └── payments.ts
│   │   ├── services/
│   │   │   └── random.ts
│   │   └── types/
│   │       ├── order.ts
│   │       └── payment.ts
│   └── docs/               # Fase 2 — Base de conocimiento
│       ├── api/
│       │   ├── overview.md
│       │   ├── orders.md
│       │   └── payments.md
│       ├── architecture/
│       │   └── system-overview.md
│       ├── development/
│       │   ├── coding-standards.md
│       │   └── adding-endpoints.md
│       └── ai/
│           ├── rag-overview.md
│           ├── rag-architecture.md
│           ├── rag-installation.md
│           ├── rag-use-cases.md
│           ├── rag-limitations.md
│           └── mcp-guidelines.md
│
├── rag/                    # Fases 3 y 4 — RAG + Persistencia
│   ├── package.json
│   ├── tsconfig.json
│   ├── .env
│   └── src/
│       ├── index.ts
│       ├── search.ts
│       ├── search-docs.ts
│       ├── vector-store.ts
│       ├── load-docs.ts
│       ├── persist.ts
│       └── build-index.ts
│
├── mcp-server/             # Fase 5 — MCP Server
│   ├── package.json
│   ├── tsconfig.json
│   ├── .env
│   └── src/
│       ├── server.ts
│       ├── api-client.ts
│       └── tools/
│           ├── search-docs.ts
│           ├── orders.ts
│           └── payments.ts
│
└── .vscode/                # Fase 6 — GitHub Copilot
    └── mcp.json
```

---

## Variables de Entorno

### `rag/.env`

| Variable | Default | Descripcion |
|---|---|---|
| `OLLAMA_BASE_URL` | `http://localhost:11434` | URL del servidor Ollama local |

### `mcp-server/.env`

| Variable | Default | Descripcion |
|---|---|---|
| `API_BASE_URL` | `http://localhost:3000` | URL de la API Mock |
| `PORT` | `3001` | Puerto del MCP Server |

---

## Guia de Uso

### Requisitos previos

- Node.js 22+
- Ollama instalado (`https://ollama.com`)
- Modelo descargado: `ollama pull nomic-embed-text`
- VS Code con GitHub Copilot (para Fase 6)

### Setup inicial

```bash
# 1. Instalar dependencias
cd api && npm install
cd ../rag && npm install
cd ../mcp-server && npm install

# 2. Construir indice RAG (requiere Ollama corriendo)
ollama serve &
cd rag && npm run build-index
```

### Ejecucion

```bash
# Terminal 1 — API Mock
cd api && npm run dev

# Terminal 2 — MCP Server
cd mcp-server && npm run dev

# Terminal 3 — Busquedas RAG directas (opcional)
cd rag && npm run search -- "tu pregunta"
```

### Uso con Copilot

1. Abrir VS Code en la raiz del proyecto
2. Abrir Copilot Chat en modo **Agent**
3. El servidor MCP se detecta automaticamente via `.vscode/mcp.json`

---

## Decisiones Tecnicas

### Por que LangChain

Provee abstracciones estandarizadas para el pipeline RAG (loaders, splitters, embeddings, vector stores). Permite cambiar componentes (ej. Ollama → OpenAI) con minimo impacto en el codigo.

### Por que Ollama en lugar de OpenAI

| Criterio | Ollama | OpenAI |
|---|---|---|
| Costo | Gratuito | Por token |
| API Key | No requiere | Requerida |
| Privacidad | Local | Datos en la nube |
| Reproducibilidad | Total | Depende de cuenta |
| Velocidad (PoC) | Suficiente | Mayor |

### Por que Streamable HTTP en lugar de SSE clasico

Streamable HTTP es el transporte recomendado en la especificacion MCP 2025-03-26. Es mas simple (un solo endpoint), no requiere mantener conexiones persistentes, y es compatible con GitHub Copilot en VS Code.

### Por que SimpleMemoryVectorStore en lugar de Chroma/Pinecone

Para un PoC educativo, una implementacion propia expone claramente el mecanismo de cosine similarity y elimina dependencias de infraestructura externa. La persistencia en JSON resuelve el problema de performance sin agregar complejidad operacional.

### Por que JSON para la persistencia del indice

Legible, sin dependencias, facil de inspeccionar y depurar. Para un sistema productivo se evaluaria una base de datos vectorial con soporte de indices (ej. LanceDB, pgvector).

### Estructura de modulos separados

Cada componente (`api`, `rag`, `mcp-server`) tiene su propio `package.json`. Esto refleja como seria en un monorepo real: cada modulo puede evolucionar, desplegarse y testearse independientemente.
