# System Overview

## Objective

Demonstrate AI-assisted developer workflows.

## Components

### API

Exposes orders and payments endpoints.

### Documentation

Provides functional and technical knowledge.

### RAG

Makes documentation searchable through semantic retrieval.

### MCP

Provides executable tools to AI agents.

### Copilot

Acts as the user-facing interface inside VS Code.

## Architecture Principle

Documentation answers questions.

MCP executes actions.

Together they provide knowledge and execution capabilities.
