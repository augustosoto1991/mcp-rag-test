# RAG Architecture

## Flow

Markdown Documents
↓
Document Loader
↓
Chunking
↓
Embeddings
↓
Vector Store
↓
Similarity Search
↓
Results

## Document Loader

Reads markdown files from the docs directory.

## Chunking

Splits large documents into smaller searchable pieces.

Current configuration:

- chunkSize: 1000
- chunkOverlap: 200

## Embeddings

Generated locally using Ollama.

Model:

nomic-embed-text

## Vector Store

Simple in-memory vector store implementation.

## Search

Uses cosine similarity to retrieve the most relevant document chunks.

```mermaid
flowchart TD

A[Markdown Docs]
--> B[Document Loader]

B --> C[Chunking]

C --> D[Ollama Embeddings]

D --> E[Memory Vector Store]

E --> F[Similarity Search]

F --> G[Developer Query]
```
