# Installation

## Requirements

- Node.js 22+
- TypeScript
- Ollama

## Install Ollama

https://ollama.com

## Pull embedding model

ollama pull nomic-embed-text

## Verify installation

ollama list

Expected:

nomic-embed-text

## Install dependencies

npm install

## Validate

npm run search -- "How do I add a new endpoint?"
