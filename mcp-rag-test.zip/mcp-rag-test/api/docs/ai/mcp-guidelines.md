# MCP Guidelines

## When to Create a Tool

Create a tool when an agent must perform a real action.

Examples:

- Create order
- Create payment
- Retrieve order

## When Not to Create a Tool

Do not create a tool only for providing information already available in documentation.

Use RAG instead.

## Principle

Use RAG for knowledge.

Use MCP for actions.
