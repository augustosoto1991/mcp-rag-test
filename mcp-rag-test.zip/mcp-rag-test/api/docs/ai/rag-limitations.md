# Limitations

## In-Memory Vector Store

The current implementation stores embeddings in memory.

Data is rebuilt every execution.

This is sufficient for educational purposes but not ideal for production.

## No Re-ranking

Results are returned directly from vector similarity.

## No Hybrid Search

Keyword search and semantic search are not combined.

## No Persistence

Embeddings are regenerated whenever the application starts.
