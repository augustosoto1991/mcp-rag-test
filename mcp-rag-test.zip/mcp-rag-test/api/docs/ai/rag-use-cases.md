# Use Cases

## Developer Onboarding

New developers can ask questions about the project structure.

Example:

How do I add a new endpoint?

## Documentation Discovery

Find information without manually browsing multiple documentation files.

## Architecture Guidance

Retrieve architecture decisions and implementation rules.

## AI Agent Context

Provide contextual information to MCP tools and AI assistants.
