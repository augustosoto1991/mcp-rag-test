# RAG Overview

## Purpose

This module provides semantic search capabilities over the project documentation.

The objective is to allow developers and AI agents to retrieve relevant information from project knowledge without manually navigating documentation files.

## Knowledge Sources

The RAG indexes:

- API documentation
- Development guidelines
- Architecture notes

## Typical Questions

- How do I add a new endpoint?
- What statuses can an order return?
- Where should route files be located?

## Key Principle

RAG provides knowledge retrieval.

It does not execute actions.

Action execution is delegated to MCP tools.
