# Orders API

## Create Order

### Endpoint

POST /orders

### Description

Creates a new order.

### Request

No request body is required.

### Response

```json
{
  "orderId": "ord_abcd1234",
  "status": "created",
  "createdAt": "2026-01-01T00:00:00Z"
}
```

### Possible Status Values

created
processing
completed

### Errors

None in the mock implementation.

---

````md
## Get Order

### Endpoint

GET /orders/:id

### Description

Returns a simulated order status.

### Response

```json
{
  "orderId": "ord_abcd1234",
  "status": "processing",
  "updatedAt": "2026-01-01T00:00:00Z"
}

Status Definitions
created
Order was successfully created.
processing
Order is being processed.
completed
Order completed successfully.
```
````
