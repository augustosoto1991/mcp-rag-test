# Order Management API

## Purpose

This API provides a simplified order and payment workflow.

The service is intentionally minimal and designed for educational purposes.

## Resources

### Orders

Used to create and retrieve orders.

### Payments

Used to simulate payment processing for existing orders.

## Flow

1. Create an order.
2. Create a payment for that order.
3. Query the order status.

## Example

Create Order
->
Create Payment
->
Check Order Status
