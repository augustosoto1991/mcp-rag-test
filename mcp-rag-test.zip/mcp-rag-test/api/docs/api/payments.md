````md
# Payments API

## Create Payment

### Endpoint

POST /payments

### Description

Creates a simulated payment associated with an order.

### Request

```json
{
  "orderId": "ord_abcd1234"
}
```

### response

```json
{
  "paymentId": "pay_xyz123",
  "orderId": "ord_abcd1234",
  "status": "approved",
  "createdAt": "2026-01-01T00:00:00Z"
}
```

### Possible Status Values

approved
declined
pending

### Status Definitions

approved
Payment accepted.
declined
Payment rejected.
pending
Payment still being evaluated.
````
