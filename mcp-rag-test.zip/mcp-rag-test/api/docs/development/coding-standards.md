```md
# Coding Standards

## Language

Use TypeScript for all source files.

## Folder Structure

Routes belong in:

src/routes

Shared business logic belongs in:

src/services

Types belong in:

src/types

## Endpoint Naming

Use resource-based naming.

Examples:

GET /orders
POST /orders

Avoid:

POST /createOrder
POST /doPayment

## Responses

Responses should use JSON.

## Documentation

Every new endpoint must be documented.

Documentation must include:

- Purpose
- Request
- Response
- Status values
- Error scenarios
```
