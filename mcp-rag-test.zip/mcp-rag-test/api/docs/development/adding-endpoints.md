# Adding a New Endpoint

Follow these steps when extending the API.

## Step 1

Create the route file.

Example:

src/routes/refunds.ts

## Step 2

Create any required types.

Example:

src/types/refund.ts

## Step 3

Add the endpoint to the main server.

server.ts

## Step 4

Document the endpoint.

Create a markdown file in:

docs/api

## Step 5

Re-index the RAG knowledge base.

This ensures the new documentation becomes searchable.

## Step 6

If the endpoint should be accessible by AI agents, create a new MCP tool.

Not every endpoint requires an MCP tool.
