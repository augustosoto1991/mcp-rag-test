export const pickRandom = <T>(items: T[]): T => {
  return items[Math.floor(Math.random() * items.length)];
};

export const randomId = (prefix: string): string => {
  return `${prefix}_${Math.random()
    .toString(36)
    .substring(2, 10)}`;
};