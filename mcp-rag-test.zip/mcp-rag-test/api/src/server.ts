import express from "express";
import cors from "cors";

import ordersRouter from "./routes/orders.js";
import paymentsRouter from "./routes/payments.js";

const app = express();

app.use(cors());
app.use(express.json());

app.get("/health", (_, res) => {
  res.json({
    status: "ok"
  });
});

app.use("/orders", ordersRouter);
app.use("/payments", paymentsRouter);

const PORT = 3000;

app.listen(PORT, () => {
  console.log(
    `API running on http://localhost:${PORT}`
  );
});