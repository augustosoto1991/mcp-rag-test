import { Router } from "express";
import { randomId, pickRandom } from "../services/random.js";

const router = Router();

router.post("/", (req, res) => {
  const statuses = [
    "approved",
    "declined",
    "pending"
  ];

  res.json({
    paymentId: randomId("pay"),
    orderId: req.body.orderId ?? randomId("ord"),
    status: pickRandom(statuses),
    createdAt: new Date().toISOString()
  });
});

export default router;