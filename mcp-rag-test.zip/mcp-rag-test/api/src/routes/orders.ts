import { Router } from "express";
import { randomId } from "../services/random.js";


const router = Router();

router.post("/", (_, res) => {
  res.json({
    orderId: randomId("ord"),
    status: "created",
    createdAt: new Date().toISOString()
  });
});

router.get("/:id", (req, res) => {
  const statuses = [
    "created",
    "processing",
    "completed"
  ];

  const status =
    statuses[Math.floor(Math.random() * statuses.length)];

  res.json({
    orderId: req.params.id,
    status,
    updatedAt: new Date().toISOString()
  });
});

export default router;