export interface Payment {
  paymentId: string;
  orderId: string;
  status: "approved" | "declined" | "pending";
  createdAt: string;
}