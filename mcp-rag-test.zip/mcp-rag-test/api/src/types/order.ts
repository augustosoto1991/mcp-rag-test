export interface Order {
  orderId: string;
  status: "created" | "processing" | "completed";
  createdAt: string;
}