# De la documentación muerta al asistente que actúa: RAG + MCP + Copilot en tu flujo de desarrollo

> Como transformar la documentación técnica de tu equipo en un asistente inteligente que responde preguntas, ejecuta acciones reales y vive dentro de tu editor. Sin vendor lock-in. Sin infraestructura costosa. Con modelos completamente locales.

---

## El problema que nadie admite pero todos sufren

Hay una conversación que ocurre en casi todos los equipos de desarrollo, con distintas variaciones pero el mismo patrón:

> *"¿Dónde van los tipos TypeScript en este proyecto?"*
>
> *"¿Cuál es el endpoint para crear una orden? ¿Está en Swagger o en Confluence?"*
>
> *"¿Cuándo debo crear un servicio nuevo vs. extender uno existente?"*

Estas preguntas parecen simples. Pero para responderlas, el desarrollador típicamente:

1. Sale del editor
2. Abre el navegador
3. Busca en Confluence, o en la wiki, o en Swagger, o en Slack
4. No encuentra nada claro
5. Le pregunta al desarrollador senior que "sabe todo"
6. Vuelve al editor, interrumpiendo el flujo de concentración

**Este ciclo se repite docenas de veces al día.** Y tiene un costo real:

- Onboarding de nuevos desarrolladores que tarda semanas en lugar de días
- Dependencia crítica de personas específicas ("el que sabe cómo funciona X")
- Documentación que se escribe pero nunca se usa porque es difícil de encontrar
- Context switching constante que destruye la productividad

El conocimiento técnico existe. El problema es que está distribuido, difícil de encontrar, y completamente desconectado del entorno donde se trabaja: el editor.

---

## La propuesta: cuatro etapas de evolución

La solución no es una herramienta nueva. Es una evolución gradual de algo que los equipos ya tienen: **documentación**.

```
Etapa 1 ─── Documentación Markdown estática
                ↓
Etapa 2 ─── Documentación + RAG
             (el conocimiento responde preguntas en lenguaje natural)
                ↓
Etapa 3 ─── RAG + MCP Server
             (el asistente también puede ejecutar acciones reales)
                ↓
Etapa 4 ─── Todo integrado en Copilot / Claude / Cline
             (sin salir del editor, sin context switching)
```

Cada etapa agrega valor incremental. Un equipo puede adoptar solo las primeras dos etapas y ya obtener beneficios significativos. Las etapas tres y cuatro son lo que convierte el sistema en algo verdaderamente poderoso.

---

## El principio fundamental

Antes de entrar en la arquitectura, hay un principio que guía todas las decisiones de diseño:

> **RAG responde preguntas. MCP ejecuta acciones.**

Cuando un desarrollador pregunta *"¿qué estados puede devolver una orden?"*, eso es una pregunta. El sistema debe buscar en la documentación y responder.

Cuando un desarrollador dice *"crea una orden y procesa el pago"*, eso es una acción. El sistema debe ejecutar llamadas reales a la API.

Esta separación clara entre conocimiento y ejecución es lo que hace al sistema robusto, predecible y fácil de extender.

---

## Arquitectura del sistema

```
Developer
    │
    ▼
Cliente MCP
(Copilot / Claude Desktop / Cline / cualquier cliente MCP)
    │
    │  Model Context Protocol — Streamable HTTP
    ▼
MCP Server  :3001
    │                         │
    ▼                         ▼
RAG Engine               API (Mock o real)
    │                         │
    ▼                         ▼
Base de conocimiento      Endpoints
(Markdown → embeddings    (/orders, /payments,
 → búsqueda semántica)     cualquier servicio)
```

Hay cuatro componentes principales. Cada uno tiene una responsabilidad única y bien delimitada.

---

### Componente 1: La base de conocimiento

El punto de partida es la documentación que el equipo ya debería tener: archivos Markdown que describen la API, los estándares de desarrollo, las decisiones arquitectónicas, y las guías para el equipo.

Lo que cambia no es el formato sino la **intención**: la documentación se escribe pensando en que será leída tanto por humanos como por sistemas de IA. Esto significa:

- Encabezados claros y jerárquicos
- Secciones cortas y enfocadas
- Listas en lugar de párrafos largos
- Bloques de código con ejemplos concretos

Esta inversión en calidad de documentación paga dividendos dobles: mejora la experiencia humana de leer los docs *y* mejora la precisión de las respuestas del RAG.

---

### Componente 2: El motor RAG

RAG significa *Retrieval Augmented Generation*. Es una técnica que permite a los modelos de lenguaje responder preguntas usando información específica, en lugar de depender solo de lo que aprendieron durante el entrenamiento.

El pipeline funciona así:

```
1. Carga de documentos
   Los archivos Markdown se leen recursivamente desde el filesystem

2. Chunking (fragmentación)
   Cada documento se divide en fragmentos de ~1000 caracteres
   con un solapamiento de 200 para no perder contexto entre fragmentos

3. Embedding
   Cada fragmento se convierte en un vector numérico (768 dimensiones)
   usando el modelo nomic-embed-text corriendo localmente en Ollama

4. Almacenamiento
   Los pares (fragmento, vector) se guardan en memoria
   y se persisten en un archivo JSON para no re-procesar en cada búsqueda

5. Búsqueda semántica
   Cuando llega una consulta:
   → se embeddea la consulta con el mismo modelo
   → se calcula la similitud coseno contra todos los vectores almacenados
   → se retornan los top-k fragmentos más relevantes
```

La clave está en el paso 5: la **similitud coseno** mide qué tan "cercanos" son dos vectores en el espacio matemático. Dos textos que hablan del mismo tema tendrán vectores similares, aunque usen palabras diferentes. Esto es lo que hace que una búsqueda semántica sea fundamentalmente superior a una búsqueda por palabras clave.

---

### Componente 3: El MCP Server

MCP (Model Context Protocol) es un protocolo abierto creado por Anthropic que estandariza cómo los modelos de lenguaje interactúan con herramientas externas. Piénsalo como una API, pero diseñada específicamente para que los modelos de IA la consuman.

El MCP Server expone **tools**: funciones con nombre, descripción y esquema de inputs/outputs que el modelo puede invocar cuando lo necesita.

En este proyecto, los tools son:

| Tool | Descripción | Implementación |
|---|---|---|
| `health_check` | Verifica el estado de todos los componentes | Chequea API, Ollama e índice RAG |
| `search_docs` | Búsqueda semántica en la documentación | Llama al motor RAG |
| `create_order` | Crea una nueva orden | `POST /orders` |
| `get_order` | Consulta el estado de una orden | `GET /orders/:id` |
| `create_payment` | Procesa un pago para una orden | `POST /payments` |

La comunicación usa **Streamable HTTP** (el estándar actual del protocolo MCP), lo que significa que el servidor es simplemente un endpoint HTTP. Cualquier cliente que hable el protocolo puede conectarse.

---

### Componente 4: El cliente (Copilot, Claude, Cline)

Este es el componente más importante desde la perspectiva del desarrollador porque es lo único que ve.

El cliente recibe la instrucción del desarrollador en lenguaje natural, decide qué tools invocar (puede ser uno o varios en secuencia), ejecuta las llamadas al MCP Server, y sintetiza los resultados en una respuesta coherente.

Lo notable es que **el MCP Server no sabe nada sobre el cliente**. Es completamente agnóstico. El mismo servidor que usa GitHub Copilot puede usarlo Claude Desktop, Cline, o cualquier otra herramienta que adopte el protocolo. No hay vendor lock-in en ninguna dirección.

---

## Por qué Ollama: la decisión que lo hace posible

Una de las decisiones más importantes del proyecto fue usar Ollama en lugar de un servicio de embeddings externo como OpenAI.

| Criterio | Ollama (local) | OpenAI / Azure |
|---|---|---|
| Costo | Cero | Por token, acumula rápido |
| API Key | No requiere | Requerida, gestionada |
| Privacidad | Los datos no salen del equipo | Procesamiento en la nube |
| Reproducibilidad | Cualquier dev puede correrlo igual | Depende de versiones del API |
| Latencia | Depende del hardware local | Depende de la red |
| Offline | Funciona sin internet | Requiere conectividad |

Para un equipo que trabaja con código propietario o información sensible, esta decisión es crítica. **Los documentos internos, los estándares y la arquitectura nunca salen del entorno local.**

Para un equipo que necesita escalar o prefiere la conveniencia, la arquitectura del proyecto facilita el cambio: basta con intercambiar `OllamaEmbeddings` por `OpenAIEmbeddings` en un solo archivo.

---

## La persistencia del índice: un detalle que cambia todo

Sin persistencia, cada búsqueda requeriría re-procesar todos los documentos: cargarlos, fragmentarlos, y generar embeddings para cada fragmento. En un sistema con decenas o cientos de documentos, esto tomaría minutos en cada consulta.

La solución implementada es simple pero efectiva: después de construir el índice por primera vez, se serializa a un archivo `index.json`. Las búsquedas subsecuentes cargan directamente desde este cache, sin tocar Ollama.

```bash
# Solo necesario una vez, o cuando cambia la documentación
cd rag && npm run build-index

# Todas las búsquedas posteriores usan el cache
npm run search -- "tu pregunta"
```

El flujo con cache convierte una operación de minutos en una de milisegundos.

---

## El tool health_check: diagnóstico desde el editor

Una adición que parece menor pero resulta muy útil en la práctica: un tool de diagnóstico del sistema.

Cuando algo no funciona, el desarrollador puede preguntar directamente en el chat:

> *"Are all systems working?"*

Y recibir:

```
✅ API Mock — http://localhost:3000
✅ RAG Index — 12 chunks loaded
✅ Ollama — http://localhost:11434
✅ Ollama model — nomic-embed-text

All systems operational.
```

O si hay un problema:

```
✅ API Mock — http://localhost:3000
❌ RAG Index — index.json not found — run: cd rag && npm run build-index
✅ Ollama — http://localhost:11434
✅ Ollama model — nomic-embed-text

One or more components need attention.
```

Sin salir del editor, sin abrir terminales adicionales, con instrucciones de resolución incluidas.

---

## No es exclusivo de Copilot: el poder del estándar abierto

Este es uno de los aspectos más importantes y menos obvios del diseño.

El MCP Server que construimos puede conectarse a cualquier cliente que implemente el protocolo MCP:

| Cliente | Tipo |
|---|---|
| GitHub Copilot | Extension de VS Code |
| Claude Desktop | Aplicación nativa de escritorio |
| Cline | Extension de VS Code (agente autónomo) |
| Roo Code | Extension de VS Code (fork de Cline) |
| Cursor | Editor basado en VS Code |
| Windsurf | Editor de Codeium |
| Continue.dev | Extension open source para VS Code y JetBrains |

La configuración para cada cliente es prácticamente idéntica: una URL apuntando al endpoint `/mcp`. El equipo puede elegir la herramienta con la que se sienta más cómodo sin cambiar nada en el servidor.

---

## Beneficios concretos por rol

### Para el desarrollador nuevo

El onboarding es el caso de uso más inmediato. En lugar de:

- Leer READMEs desactualizados
- Preguntar a compañeros que están en medio de otra tarea
- Explorar el código para inferir convenciones

El desarrollador puede preguntar directamente:

> *"How do I add a new endpoint to this project?"*
> *"Where should I put the TypeScript types?"*
> *"What's the standard error handling pattern here?"*

Y recibe respuestas basadas en la documentación real del proyecto, inmediatamente, sin interrumpir a nadie.

---

### Para el desarrollador senior

El desarrollador senior es típicamente el cuello de botella del conocimiento. Responder las mismas preguntas repetidamente tiene un costo de productividad real.

Con este sistema, el conocimiento que ese desarrollador tiene en la cabeza se externaliza a la base de conocimiento del RAG. Las preguntas frecuentes se responden automáticamente. El tiempo del senior se libera para trabajo de mayor valor.

---

### Para el tech lead

Los estándares de desarrollo son inútiles si nadie los encuentra cuando los necesita. Con el RAG indexando la documentación de estándares, el equipo puede consultar las convenciones en contexto, en el momento en que las necesita, sin interrumpir el flujo de trabajo.

> *"Should I use async/await or promises here?"*
> *"What's the naming convention for service files?"*

---

### Para el equipo en conjunto

- **Menos dependencia de expertos específicos**: el conocimiento es accesible para todos
- **Onboarding más rápido**: días en lugar de semanas para que un nuevo desarrollador sea productivo
- **Documentación que se usa**: cuando la documentación genera valor real, hay más incentivo para mantenerla actualizada
- **Reducción de interrupciones**: las preguntas de bajo nivel se responden sin interrumpir a otros

---

### Para la organización

- **Retención de conocimiento institucional**: cuando un desarrollador experimentado se va, su conocimiento permanece en el sistema
- **Escalabilidad**: agregar más documentación amplía las capacidades del asistente sin cambiar la infraestructura
- **Auditoría**: todas las consultas y acciones pasan por el MCP Server, lo que permite logging y trazabilidad

---

## Cómo llevarlo a un sistema real

Este proyecto es un PoC educativo. Lleva el enfoque a un sistema productivo requiere algunas adaptaciones:

### Reemplazar la fuente de conocimiento

En lugar de archivos Markdown locales:

```
Confluence / Notion    →  loader que consume la API de la plataforma
Swagger / OpenAPI      →  loader que procesa especificaciones YAML/JSON
Repositorios Git       →  loader que indexa README, ADRs, documentación inline
Base de datos interna  →  loader que consulta y estructura el conocimiento
```

El pipeline RAG (chunking → embedding → similitud) permanece igual. Solo cambia el loader.

---

### Reemplazar Ollama por embeddings en la nube

Si el equipo prefiere no gestionar modelos locales o necesita mayor calidad:

```typescript
// Cambio en un solo archivo: rag/src/vector-store.ts
// Antes:
import { OllamaEmbeddings } from "@langchain/ollama";
const embeddings = new OllamaEmbeddings({ model: "nomic-embed-text" });

// Después:
import { OpenAIEmbeddings } from "@langchain/openai";
const embeddings = new OpenAIEmbeddings({ model: "text-embedding-3-small" });
```

---

### Agregar autenticación al MCP Server

Para entornos donde el servidor es accesible en red:

```typescript
// Middleware de autenticación en server.ts
app.use('/mcp', (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token !== process.env.MCP_AUTH_TOKEN) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
});
```

---

### Vector store con persistencia robusta

Para grandes volúmenes de documentación, reemplazar el JSON plano por una base de datos vectorial:

```typescript
// Opciones según el caso de uso:
// LanceDB    → embebida, sin servidor, ideal para equipos pequeños
// pgvector   → extensión de PostgreSQL, integra con infraestructura existente
// Pinecone   → SaaS, escalabilidad automática
// Weaviate   → open source, self-hosted
```

---

### Conectar a APIs reales

Los tools del MCP Server son simplemente funciones TypeScript. Reemplazar las llamadas al mock por llamadas a servicios reales es directo:

```typescript
// Antes: API Mock local
const order = await apiClient.createOrder();

// Después: servicio real con autenticación
const order = await realOrderService.create({
  headers: { Authorization: `Bearer ${process.env.SERVICE_TOKEN}` }
});
```

---

## El camino de adopción recomendado

No es necesario implementar todo desde el primer día. El valor se puede capturar de forma incremental:

**Semana 1-2: Documentación + RAG**
- Auditar y estructurar la documentación existente
- Configurar Ollama y construir el primer índice
- Validar que las búsquedas sean relevantes

**Semana 3-4: MCP Server básico**
- Exponer `search_docs` y `health_check`
- Conectar con el cliente que prefiera el equipo
- Medir el uso y recopilar feedback

**Mes 2: Expansión gradual**
- Agregar tools para las acciones más frecuentes
- Ampliar la base de conocimiento con más documentación
- Iterar sobre la calidad de los chunks y los embeddings

**Mes 3+: Integración profunda**
- Conectar a sistemas reales
- Agregar logging y métricas de uso
- Explorar casos de uso más complejos (workflows multi-step)

---

## Conclusión

La pregunta que debería hacerse todo tech lead no es *"¿deberíamos adoptar IA en nuestro flujo de desarrollo?"*, sino *"¿cuánto conocimiento valioso está atrapado en lugares donde nadie lo encuentra?"*

RAG, MCP y los clientes de IA como Copilot o Claude no son soluciones mágicas. Son herramientas que amplifican el valor de algo que el equipo ya debería tener: **documentación técnica de calidad**.

El sistema que construimos en este PoC demuestra que:

1. La barrera de entrada es baja: Node.js, TypeScript, y Ollama son suficientes para el MVP
2. No hay lock-in: el mismo servidor funciona con Copilot, Claude, Cline y cualquier cliente MCP futuro
3. La privacidad es posible: los modelos locales procesan el conocimiento interno sin enviarlo a terceros
4. La evolución es gradual: cada etapa entrega valor independiente

El desarrollador del futuro no va a buscar en Confluence. Va a preguntar en su editor, obtener una respuesta basada en el conocimiento real del equipo, y ejecutar la acción necesaria, todo sin cambiar de contexto.

Ese futuro se puede construir hoy, con herramientas open source, en un fin de semana.

---

## Referencias y recursos

- [Model Context Protocol](https://modelcontextprotocol.io) — Especificación oficial del protocolo
- [Ollama](https://ollama.com) — Modelos de lenguaje locales
- [LangChain TypeScript](https://js.langchain.com) — Framework de orquestación RAG
- [MCP SDK TypeScript](https://github.com/modelcontextprotocol/typescript-sdk) — SDK oficial para construir servidores MCP
- [Código del proyecto](https://github.com) — Repositorio completo con todas las fases implementadas

---

*Este artículo acompaña el repositorio `mcp-rag-test`, un PoC educativo con implementación completa de todas las fases descritas.*
