import { buildVectorStore } from "./vector-store.js";

export async function searchDocs(
  query: string,
  limit = 5
) {
  const store =
    await buildVectorStore();

  const results =
    await store.similaritySearch(
      query,
      limit
    );

  return results.map(result => ({
    source: result.metadata.source,
    content: result.pageContent,
  }));
}