import { searchDocs } from "./search-docs.js";

async function main() {
  const query =
    ((globalThis as any).process?.argv ?? []).slice(2).join(" ") ||
    "How do I add a new endpoint?";

  const results =
    await searchDocs(query);

  console.log(
    JSON.stringify(results, null, 2)
  );
}

main().catch(console.error);