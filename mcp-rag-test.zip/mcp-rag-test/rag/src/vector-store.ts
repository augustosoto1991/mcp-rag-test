import 'dotenv/config';
import process from 'process';
import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";
import { OllamaEmbeddings } from "@langchain/ollama";
import { VectorStore } from "@langchain/core/vectorstores";
import { Embeddings } from "@langchain/core/embeddings";
import { Document, DocumentInterface } from "@langchain/core/documents";

import { loadDocs } from "./load-docs.js";
import { saveIndex, loadIndex } from "./persist.js";

class SimpleMemoryVectorStore extends VectorStore {

async addVectors(vectors: number[][], documents: DocumentInterface[]): Promise<string[] | void> {
  documents.forEach((doc, i) => {
    this.documents.push({ content: doc as Document, embedding: vectors[i] });
  });
  return documents.map((_, i) => String(i));
}

  embeddings: Embeddings;
  documents: Array<{ content: Document; embedding: number[] }> = [];

  constructor(embeddings: Embeddings) {
    super(embeddings, {});
    this.embeddings = embeddings;
  }

  _vectorstoreType(): string {
    return "simplemememory";
  }

  async addDocuments(docs: Document[]): Promise<string[]> {
    for (const doc of docs) {
      const embedding = await this.embeddings.embedQuery(doc.pageContent);
      this.documents.push({ content: doc, embedding });
    }
    return docs.map((_, i) => String(i));
  }

  async similaritySearchVectorWithScore(
    query: number[],
    k: number = 4
  ): Promise<[Document, number][]> {
    const similarities = this.documents.map(doc => ({
      doc: doc.content,
      similarity: this.cosineSimilarity(query, doc.embedding)
    }));

    return similarities
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, k)
      .map(item => [item.doc, item.similarity]);
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    const dotProduct = a.reduce((sum, val, i) => sum + val * b[i], 0);
    const magnitudeA = Math.sqrt(a.reduce((sum, val) => sum + val * val, 0));
    const magnitudeB = Math.sqrt(b.reduce((sum, val) => sum + val * val, 0));
    return dotProduct / (magnitudeA * magnitudeB);
  }
}

export async function buildVectorStore(forceRebuild = false) {
  const embeddings = new OllamaEmbeddings({
    model: "nomic-embed-text",
    baseUrl: process.env.OLLAMA_BASE_URL ?? "http://localhost:11434",
  });

  const store = new SimpleMemoryVectorStore(embeddings);

  // Intentar cargar indice persistido
  if (!forceRebuild) {
    const cached = await loadIndex();
    if (cached) {
      console.log(`Loaded index from cache (${cached.length} chunks)`);
      store.documents = cached;
      return store;
    }
  }

  // Construir desde cero
  console.log("Building index from docs...");
  const docs = await loadDocs();

  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 1000,
    chunkOverlap: 200,
  });

  const chunks = await splitter.splitDocuments(docs);
  await store.addDocuments(chunks);
  await saveIndex(store.documents);

  return store;
}
