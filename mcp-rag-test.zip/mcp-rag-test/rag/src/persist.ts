import { readFile, writeFile } from "fs/promises";
import { existsSync } from "fs";
import { resolve } from "path";
import { Document } from "@langchain/core/documents";

const INDEX_PATH = resolve(
  new URL(".", import.meta.url).pathname,
  "../../index.json"
);

export interface PersistedEntry {
  content: { pageContent: string; metadata: Record<string, unknown> };
  embedding: number[];
}

export async function saveIndex(
  documents: Array<{ content: Document; embedding: number[] }>
): Promise<void> {
  const serializable: PersistedEntry[] = documents.map(({ content, embedding }) => ({
    content: { pageContent: content.pageContent, metadata: content.metadata },
    embedding,
  }));
  await writeFile(INDEX_PATH, JSON.stringify(serializable, null, 2), "utf-8");
  console.log(`Index saved to ${INDEX_PATH} (${documents.length} chunks)`);
}

export async function loadIndex(): Promise<
  Array<{ content: Document; embedding: number[] }> | null
> {
  if (!existsSync(INDEX_PATH)) return null;

  const raw = await readFile(INDEX_PATH, "utf-8");
  const entries: PersistedEntry[] = JSON.parse(raw);

  return entries.map(({ content, embedding }) => ({
    content: new Document({
      pageContent: content.pageContent,
      metadata: content.metadata,
    }),
    embedding,
  }));
}
