import { buildVectorStore } from "./vector-store.js";

async function main() {
  console.log("Force-rebuilding index from docs...");
  const store = await buildVectorStore(true);
  console.log(`Done. ${store.documents.length} chunks indexed.`);
}

main().catch(console.error);
