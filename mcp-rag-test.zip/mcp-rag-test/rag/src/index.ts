import { buildVectorStore } from "./vector-store.js";

async function main() {
  console.log(
    "Building vector store..."
  );

  const store =
    await buildVectorStore();

  const results =
    await store.similaritySearch(
      "How do I add a new endpoint?",
      3
    );

  console.log(
    JSON.stringify(
      results.map(r => ({
        source: r.metadata.source,
      })),
      null,
      2
    )
  );
}

main().catch(console.error);