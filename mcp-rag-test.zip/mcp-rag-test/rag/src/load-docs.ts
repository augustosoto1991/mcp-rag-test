import fs from "node:fs";
import path from "node:path";
import { Document } from "@langchain/core/documents";

const DOCS_ROOT = path.resolve("../api/docs");

function getMarkdownFiles(dir: string): string[] {
  const entries = fs.readdirSync(dir, {
    withFileTypes: true,
  });

  let files: string[] = [];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      files.push(...getMarkdownFiles(fullPath));
    }

    if (
      entry.isFile() &&
      entry.name.endsWith(".md")
    ) {
      files.push(fullPath);
    }
  }

  return files;
}

export async function loadDocs() {
  const files = getMarkdownFiles(DOCS_ROOT);

  return files.map(
    file =>
      new Document({
        pageContent: fs.readFileSync(
          file,
          "utf-8"
        ),
        metadata: {
          source: path.relative(
            DOCS_ROOT,
            file
          ),
        },
      })
  );
}