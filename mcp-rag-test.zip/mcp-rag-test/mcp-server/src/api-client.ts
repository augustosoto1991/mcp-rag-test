import 'dotenv/config';

const BASE_URL = process.env.API_BASE_URL ?? 'http://localhost:3000';

export interface Order {
  orderId: string;
  status: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Payment {
  paymentId: string;
  orderId: string;
  status: string;
  createdAt: string;
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    throw new Error(`API error: ${res.status} ${res.statusText} — ${method} ${path}`);
  }

  return res.json() as Promise<T>;
}

export const apiClient = {
  createOrder: () =>
    request<Order>('POST', '/orders'),

  getOrder: (orderId: string) =>
    request<Order>('GET', `/orders/${orderId}`),

  createPayment: (orderId: string) =>
    request<Payment>('POST', '/payments', { orderId }),
};
