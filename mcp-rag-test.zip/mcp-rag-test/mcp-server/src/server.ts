import 'dotenv/config';
import express from 'express';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';

import { registerSearchDocsTool } from './tools/search-docs.js';
import { registerOrderTools } from './tools/orders.js';
import { registerPaymentTools } from './tools/payments.js';
import { registerHealthTool } from './tools/health.js';

const PORT = Number(process.env.PORT ?? 3001);

// --- MCP Server setup ---

const server = new McpServer({
  name: 'mcp-rag-test',
  version: '1.0.0',
});

registerSearchDocsTool(server);
registerOrderTools(server);
registerPaymentTools(server);
registerHealthTool(server);

// --- Express + Streamable HTTP transport ---

const app = express();
app.use(express.json());

const transport = new StreamableHTTPServerTransport({
  sessionIdGenerator: undefined, // stateless — no session management needed
});

// MCP endpoint: POST (client → server calls) and GET (server → client notifications)
app.all('/mcp', async (req, res) => {
  await transport.handleRequest(req, res, req.body);
});

await server.connect(transport);

app.listen(PORT, () => {
  console.log(`MCP Server running at http://localhost:${PORT}/mcp`);
  console.log('Tools registered: health_check, search_docs, create_order, get_order, create_payment');
});
