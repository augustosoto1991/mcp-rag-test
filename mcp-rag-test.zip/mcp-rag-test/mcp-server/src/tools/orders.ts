import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { apiClient } from '../api-client.js';

export function registerOrderTools(server: McpServer) {
  server.registerTool(
    'create_order',
    {
      title: 'Create Order',
      description: 'Creates a new order in the system. No input required.',
      inputSchema: {},
    },
    async () => {
      const order = await apiClient.createOrder();
      return {
        content: [
          {
            type: 'text',
            text: `Order created successfully:\n\`\`\`json\n${JSON.stringify(order, null, 2)}\n\`\`\``,
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_order',
    {
      title: 'Get Order',
      description: 'Retrieves the current status of an existing order by its ID.',
      inputSchema: {
        orderId: z.string().describe('The order ID to look up (e.g. ord_abc123)'),
      },
    },
    async ({ orderId }) => {
      const order = await apiClient.getOrder(orderId);
      return {
        content: [
          {
            type: 'text',
            text: `Order status:\n\`\`\`json\n${JSON.stringify(order, null, 2)}\n\`\`\``,
          },
        ],
      };
    }
  );
}
