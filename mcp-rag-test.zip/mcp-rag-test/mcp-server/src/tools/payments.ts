import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { apiClient } from '../api-client.js';

export function registerPaymentTools(server: McpServer) {
  server.registerTool(
    'create_payment',
    {
      title: 'Create Payment',
      description: 'Creates a payment for an existing order. Returns the payment status (approved, declined, or pending).',
      inputSchema: {
        orderId: z.string().describe('The order ID to process payment for (e.g. ord_abc123)'),
      },
    },
    async ({ orderId }) => {
      const payment = await apiClient.createPayment(orderId);
      return {
        content: [
          {
            type: 'text',
            text: `Payment processed:\n\`\`\`json\n${JSON.stringify(payment, null, 2)}\n\`\`\``,
          },
        ],
      };
    }
  );
}
