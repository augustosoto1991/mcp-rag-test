import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { searchDocs } from '../../../rag/src/search-docs.js';

export function registerSearchDocsTool(server: McpServer) {
  server.registerTool(
    'search_docs',
    {
      title: 'Search Documentation',
      description:
        'Searches the project documentation using semantic similarity. ' +
        'Use this to answer questions about the API, architecture, development standards, ' +
        'or any other knowledge available in the docs.',
      inputSchema: {
        query: z.string().describe('The question or topic to search for in the documentation'),
        limit: z.number().int().min(1).max(10).optional().describe('Max number of results to return (default: 5)'),
      },
    },
    async ({ query, limit = 5 }) => {
      const results = await searchDocs(query, limit);

      if (results.length === 0) {
        return {
          content: [{ type: 'text', text: 'No relevant documentation found for that query.' }],
        };
      }

      const formatted = results
        .map((r, i) => `## Result ${i + 1}\n**Source:** ${r.source}\n\n${r.content}`)
        .join('\n\n---\n\n');

      return {
        content: [{ type: 'text', text: formatted }],
      };
    }
  );
}
