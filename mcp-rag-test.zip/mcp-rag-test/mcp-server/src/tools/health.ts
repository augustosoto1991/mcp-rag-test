import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { existsSync, readFileSync } from 'fs';
import { resolve } from 'path';
import { fileURLToPath } from 'url';

const INDEX_PATH = resolve(
  fileURLToPath(new URL('.', import.meta.url)),
  '../../../index.json'
);

const API_BASE_URL = process.env.API_BASE_URL ?? 'http://localhost:3000';
const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL ?? 'http://localhost:11434';

async function checkHttp(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(3000) });
    return res.ok;
  } catch {
    return false;
  }
}

async function checkOllamaModel(): Promise<boolean> {
  try {
    const res = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      signal: AbortSignal.timeout(3000),
    });
    if (!res.ok) return false;
    const data = (await res.json()) as { models: { name: string }[] };
    return data.models.some(m => m.name.startsWith('nomic-embed-text'));
  } catch {
    return false;
  }
}

function checkIndex(): { ok: boolean; chunks: number | null } {
  if (!existsSync(INDEX_PATH)) return { ok: false, chunks: null };
  try {
    const raw = readFileSync(INDEX_PATH, 'utf-8');
    const data = JSON.parse(raw);
    return { ok: true, chunks: Array.isArray(data) ? data.length : null };
  } catch {
    return { ok: false, chunks: null };
  }
}

export function registerHealthTool(server: McpServer) {
  server.registerTool(
    'health_check',
    {
      title: 'Health Check',
      description:
        'Checks the status of all system components: API Mock, RAG index, and Ollama. ' +
        'Run this first if something is not working as expected.',
      inputSchema: {},
    },
    async () => {
      const [apiOk, ollamaOk, ollamaModelOk] = await Promise.all([
        checkHttp(`${API_BASE_URL}/health`),
        checkHttp(`${OLLAMA_BASE_URL}/api/tags`),
        checkOllamaModel(),
      ]);

      const index = checkIndex();

      const status = (ok: boolean, label: string) =>
        `${ok ? '✅' : '❌'} ${label}`;

      const lines = [
        '## System Health Check',
        '',
        status(apiOk, `API Mock — ${API_BASE_URL}`),
        status(index.ok, `RAG Index — ${index.ok ? `${index.chunks} chunks loaded` : 'index.json not found — run: cd rag && npm run build-index'}`),
        status(ollamaOk, `Ollama — ${OLLAMA_BASE_URL}`),
        status(ollamaModelOk, `Ollama model — nomic-embed-text${!ollamaModelOk ? ' (run: ollama pull nomic-embed-text)' : ''}`),
        '',
        apiOk && index.ok && ollamaOk && ollamaModelOk
          ? '**All systems operational.**'
          : '**One or more components need attention. See above.**',
      ];

      return {
        content: [{ type: 'text', text: lines.join('\n') }],
      };
    }
  );
}
