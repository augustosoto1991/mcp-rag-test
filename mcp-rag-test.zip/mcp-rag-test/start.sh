#!/usr/bin/env bash
# start.sh — Levanta todos los servicios del proyecto en una sesion tmux con paneles separados
#
# Layout:
#   ┌─────────────────────┬─────────────────────┐
#   │   API Mock          │   MCP Server        │
#   │   :3000             │   :3001             │
#   └─────────────────────┴─────────────────────┘
#
# Uso: ./start.sh
# Requiere: tmux, Node.js 22+, Ollama corriendo con nomic-embed-text

set -e

SESSION="mcp-rag-test"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Colores ────────────────────────────────────────────────────────────────
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

# ─── Prerequisitos ──────────────────────────────────────────────────────────
echo -e "${CYAN}Verificando prerequisitos...${NC}"

if ! command -v tmux &> /dev/null; then
  echo -e "${RED}✗ tmux no esta instalado.${NC}"
  echo "  Instalalo con: brew install tmux"
  exit 1
fi
echo -e "${GREEN}✓ tmux disponible${NC}"

if ! command -v node &> /dev/null; then
  echo -e "${RED}✗ Node.js no esta instalado.${NC}"
  exit 1
fi
echo -e "${GREEN}✓ Node.js $(node --version)${NC}"

if ! curl -s --max-time 2 http://localhost:11434/api/tags &> /dev/null; then
  echo -e "${YELLOW}⚠ Ollama no parece estar corriendo en localhost:11434${NC}"
  echo "  Inicialo con: ollama serve"
  echo "  (Continuando de todas formas — lo necesitaras para search_docs)"
else
  echo -e "${GREEN}✓ Ollama disponible${NC}"
fi

if [ ! -f "$ROOT/index.json" ]; then
  echo -e "${YELLOW}⚠ index.json no encontrado — el RAG no tendra datos.${NC}"
  echo "  Generalo con: cd rag && npm run build-index"
  echo "  (Continuando de todas formas)"
else
  echo -e "${GREEN}✓ RAG index encontrado${NC}"
fi

echo ""

# ─── Matar sesion existente si hay una ──────────────────────────────────────
if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo -e "${YELLOW}Sesion tmux '$SESSION' ya existe. Matandola...${NC}"
  tmux kill-session -t "$SESSION"
  sleep 1
fi

# ─── Crear sesion y paneles ──────────────────────────────────────────────────
# Panel izquierdo: API Mock
tmux new-session -d -s "$SESSION" -x "$(tput cols)" -y "$(tput lines)"
tmux send-keys -t "$SESSION" "cd '$ROOT/api' && echo -e '\\033[0;36m[ API Mock — :3000 ]\\033[0m' && npm run dev" Enter

# Panel derecho: MCP Server
tmux split-window -h -t "$SESSION"
tmux send-keys -t "$SESSION" "cd '$ROOT/mcp-server' && echo -e '\\033[0;36m[ MCP Server — :3001 ]\\033[0m' && npm run dev" Enter

# Volver al panel izquierdo
tmux select-pane -t "$SESSION:0.0"

# ─── Adjuntar ───────────────────────────────────────────────────────────────
echo -e "${GREEN}Servicios iniciados. Adjuntando a la sesion tmux...${NC}"
echo -e "${CYAN}Para salir sin matar los servicios: Ctrl+B → D${NC}"
echo -e "${CYAN}Para detener todo: ./stop.sh${NC}"
echo ""

tmux attach-session -t "$SESSION"
