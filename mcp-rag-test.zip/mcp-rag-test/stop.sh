#!/usr/bin/env bash
# stop.sh — Detiene todos los servicios del proyecto matando la sesion tmux
#
# Uso: ./stop.sh

SESSION="mcp-rag-test"

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}Deteniendo servicios de $SESSION...${NC}"

if tmux has-session -t "$SESSION" 2>/dev/null; then
  tmux kill-session -t "$SESSION"
  echo -e "${GREEN}✓ Sesion tmux '$SESSION' terminada.${NC}"
else
  echo -e "${RED}No se encontro una sesion tmux activa con el nombre '$SESSION'.${NC}"
fi
